package com.umanizales.apipaseoperros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApipaseoperrosApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApipaseoperrosApplication.class, args);
    }

}

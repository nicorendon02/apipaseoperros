package com.umanizales.apipaseoperros.repository;

import com.umanizales.apipaseoperros.model.entities.TipoUsuario;
import org.springframework.data.repository.CrudRepository;

public interface TipoUsuarioRepository extends CrudRepository<TipoUsuario,Short> {
}
